ruby-exercises
==============

_This project is setup to commit exercises in Ruby weekly._

### List Exercises

1. [Week 4 - Rails Demo app - 31/10](https://github.com/zzswat/ruby-exercises/tree/master/demo_app)
2. [Week 5 - Rails Sample app - 10/11](https://github.com/zzswat/ruby-exercises/tree/master/sample_app)
3. [Week 7 - Rails Sample app with Signup - 24/11](https://github.com/zzswat/ruby-exercises/tree/master/sample_app)

### Exercises Reference

All exercises and process can be viewed [here](https://docs.google.com/spreadsheets/d/1IXnxsmQzU3MwYU7-RV93hwuFgX4KQSf9joHvwWvAMMc/edit?usp=sharing)

© 2014 Phan Van Hau

Hedspi 6C K56

Hanoi University of Science and Technology
